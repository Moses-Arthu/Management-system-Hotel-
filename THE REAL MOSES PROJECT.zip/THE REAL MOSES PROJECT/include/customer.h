#ifndef CUSTOMER_H
#define CUSTOMER_H

#include <string>

using namespace std;

			//Class Customer
class customer
{
    public:
        string name;	   			 //CUSTOMER FULL NAME
        string address;				//CUSTOMER ADDRESS
        string phone;				//CONTACT NUMBER
        int days=0;	    			//DURATION OF STAY
        float payment_advance;		//ADVANCE PAYMENT
        double bill=0;				//BILL AMT
        int booking_id;				//BOOKING ID
        int room;					//ROOM NO
        int status;

        customer();
        void accept();				//ACCEPT CUSTOMER DETAILS
        void display();				//DISPLAY CUSTOMER DETAILS
        friend class room;
        friend class Hotel;
};
#endif // CUSTOMER_H
