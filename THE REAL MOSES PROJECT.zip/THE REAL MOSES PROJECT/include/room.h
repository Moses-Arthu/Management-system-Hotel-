#ifndef ROOM_H
#define ROOM_H

  //CLASS ROOM
 //TO STORE DATA OF ALL ROOMS IN THE HOTEL
class room
{
public:
	char type;				//COMFORT SUITE OR NORMAL ROOM
	char stype;				//BIG SIZE OR SMALL SIZED ROOM
	char ac;				//AC OR NO AC
	int roomNumber;			//ROOM NUMBER
	double rent;			//DAILY RENT OF ROOM
	int status=0;			//ROOM IS BOOKED OR NOT

	friend class Hotel;
	void acceptroom(int rno);//ADD ROOMS TO HOTEL DATABASE
	void displayroom();		//DISPLAY ROOMS
	room();					//DEFAULT CONSTRUCTOR
};

#endif // ROOM_H
