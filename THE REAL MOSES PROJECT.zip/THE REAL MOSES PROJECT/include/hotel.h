#ifndef HOTEL_H
#define HOTEL_H

#include "customer.h"
#include "room.h"

//class Hotel
class hotel
{
public:
	room a[100];			//ARRAY OF ROOMS
	customer c[100];		//ARRAY OF CUSTOMERS
	int nroom=0, ncust=0;	//NO OF ROOMS AND CUSTOMERS
	bool password_check;    //CHECK PASSWORD

    void password();        //ADD PASSWORD FOR THE ADMIN
	void addRooms();		//ADD ROOMS TO DATABASE
	void searchroom();		//SEARCH FOR A PARTICULAR ROOM
	void CheckIn();			//FOR CUSTOMER CHECKIN
	void searchcust();		//SEARCH WHETHER A PARTICULAR CUSTOMER IS STAYING AT THE HOTEL
	void availability();	//CHECK AVAILABILITY OF ROOMS
	void CheckOut();		//CHECKOUT AND BILLING PROCEDURE
	void Summary();			//GUEST SUMMARY
	hotel();
};

#endif // HOTEL_H
