#include "customer.h"

#include<iostream>
#include<string.h>
#include <iomanip>
#include <ctime>
using namespace std;


customer::customer()//ASSIGNING THE VARIABLES TO ZERO
{
        days=0;
		payment_advance=0;
		bill=0;
		booking_id=0;
		status=0;
		room=0;
}

void customer::accept()		//ACCEPTING CUSTOMER DETAILS
{
	cout<<"Enter customer name: ";
	getline(cin, name);
	getline(cin, name);
	cout<<"Enter Customer address: ";
	getline(cin,address);
	flag:
	cout<<"Enter mobile number: ";
	cin>>phone;
	for(int i=0;i<(phone.length());i++)	//PHONE NUMBER VALIDATIONS
  	{									//PHONE NUMBER NEEDS TO BE ALL DIGITS AND 10 IN LENGTH
		if(!isdigit(phone[i]))
		{
			cout<<"Please your phone number has to be in digits.\n";
			goto flag;
		}
  	}
  	if(phone.length()!=10)		//PHONE LENGTH VALIDATIONS
  	{
  	  cout<<"Phone number should be 10 digits.\n";
  	  goto flag;
 	 }
}
//

void customer::display()		//DISPLAYING CUSTOMER DETAILS
{
	cout<<booking_id<<"\t\t";
	cout<<"| "<<left<<setfill(' ')<<setw(30)<<name;
	cout<<"| "<<phone<<"\t\t\t";
	cout<<"| "<<left<<setfill(' ')<<setw(30)<<address;
	cout<<"| "<<room<<"\t\t\t";
	if(status==1){cout<<"|\t\t-\t\t|"<<endl;}
	else{cout<<"|\tCHECKED OUT.\t\t|"<<endl;}
}
