
import datetime

class Customer:
    def __init__(self):
        self.name = ""
        self.address = ""
        self.phone = ""
        self.days = 0
        self.payment_advance = 0
        self.bill = 0
        self.booking_id = 0
        self.room = 0
        self.status = 0

    def accept(self):
        self.name = input("Enter customer name: ")
        self.address = input("Enter Customer address: ")
        while True:
            phone = input("Enter mobile number: ")
            if phone.isdigit() and len(phone) == 10:
                self.phone = phone
                break
            else:
                print("Phone number should be 10 digits and contain only digits. Please re-enter.")

    def display(self):
        print(f"{self.booking_id}\t\t| {self.name:30} | {self.phone:15} | {self.address:30} | {self.room}\t\t\t| {'CHECKED IN' if self.status == 1 else 'CHECKED OUT'}\t\t|")

class Room:
    def __init__(self):
        self.type = ""
        self.stype = ""
        self.ac = ""
        self.roomNumber = 0
        self.rent = 0
        self.status = 0

    def acceptroom(self, rno):
        self.roomNumber = rno
        self.ac = input("Type AC/Non-AC (A/N): ").upper()
        while self.ac not in ['A', 'N']:
            self.ac = input("Please Re-Enter Type: AC/Non-AC (A/N): ").upper()

        self.type = input("Type Comfort Suite or Normal (S/N): ").upper()
        while self.type not in ['S', 'N']:
            self.type = input("Please Re-enter Type Comfort Suite or Normal (S/N): ").upper()

        self.stype = input("Type Size (B/S): ").upper()
        while self.stype not in ['B', 'S']:
            self.stype = input("Please Re-enter Type Size (B/S): ").upper()

        self.rent = float(input("Daily Rent: "))
        while self.rent < 0 or self.rent > 20000:
            self.rent = float(input("Please enter valid rent: "))

        self.status = 0
        print("\nRoom Added Successfully!")

    def displayroom(self):
        print(f"| {self.roomNumber}.\t\t|\t{self.ac}\t\t|\t{self.type}\t\t|\t{self.stype}\t\t|\t{self.rent}\t\t|\t{'Available' if self.status == 0 else 'Booked'}\t\t|")

class Hotel:
    def __init__(self):
        self.a = [Room() for _ in range(100)]
        self.c = [Customer() for _ in range(100)]
        self.nroom = 0
        self.ncust = 0

    def addRooms(self):
        
            
        
        nroom = int(input("Enter number of rooms: "))
        while nroom <= 0:
            nroom = int(input("Invalid. Enter valid number of rooms: "))

        for i in range(nroom):
            print(f"ROOM {i+1}")
            while True:
                rno = int(input("Enter room number: "))
                if rno <= 0:
                    print("This room number is invalid! Please re-enter the room number.")
                elif any(r.roomNumber == rno for r in self.a[:i]):
                    print("Invalid. Repetitive room numbers.")
                else:
                    self.a[i].acceptroom(rno)
                    break

        self.nroom += nroom

    def availability(self):
        if self.nroom == 0:
            print("Please add rooms.")
            return

        print("The list of all available rooms:")
        print("| Room No.\t| AC/Non-AC\t| Type\t\t| Stype\t\t| Rent\t\t| Availability  \t|")
        for i in range(self.nroom):
            self.a[i].displayroom()

    def searchroom(self):
        if self.nroom == 0:
            print("Please add rooms.")
            return

        ac1 = input("Do you want AC or Non-AC? (A/N): ").upper()
        type1 = input("Do you want suite or normal room? (S/N): ").upper()
        stype1 = input("Size? (B/S): ").upper()

        found_rooms = [room for room in self.a[:self.nroom] if room.ac == ac1 and room.type == type1 and room.stype == stype1]

        if found_rooms:
            print("Room found")
            print("| Room No.\t| AC/Non-AC\t| Type\t\t| Stype\t\t| Rent\t\t| Availability  \t|")
            for room in found_rooms:
                room.displayroom()
        else:
            print("No such room is available.")

    def CheckIn(self):
        if self.nroom == 0:
            print("Please add rooms.")
            return

        if self.ncust < self.nroom:
            self.c[self.ncust].booking_id = self.ncust + 1

            while True:
                rno = int(input("Enter room number: "))
                room_index = next((i for i, room in enumerate(self.a[:self.nroom]) if room.roomNumber == rno), None)
                if room_index is not None:
                    break
                else:
                    print("Invalid room number. Please enter again.")

            if self.a[room_index].status == 0:
                print("Room available.")
                self.a[room_index].displayroom()

                ch2 = input("Do you wish to continue? Press (Y/y): ")
                if ch2.lower() == 'y':
                    self.c[self.ncust].accept()

                    self.c[self.ncust].days = int(input("Enter number of days of stay: "))
                    self.c[self.ncust].bill = self.c[self.ncust].days * self.a[room_index].rent

                    print(f"Your total bill will be approx Rs. {self.c[self.ncust].bill:.2f}. Min adv payment = {self.c[self.ncust].bill / 4:.2f}")
                    self.c[self.ncust].payment_advance = float(input("What will you be paying? "))
                    while self.c[self.ncust].payment_advance < self.c[self.ncust].bill / 4 or self.c[self.ncust].payment_advance > self.c[self.ncust].bill:
                        self.c[self.ncust].payment_advance = float(input("Enter valid amount: "))

                    print("Thank you. Booking confirmed.")
                    print("--------------------------------------------------------------")
                    print(f"Booking Id: {self.c[self.ncust].booking_id}")
                    print(f"Name: {self.c[self.ncust].name}")
                    print(f"Room no.: {rno}")
                    print("Date: ", datetime.datetime.now().ctime())

                    self.a[room_index].status = 1
                    self.c[self.ncust].room = rno
                    self.c[self.ncust].status = 1
                    self.ncust += 1
                else:
                    print("Booking canceled.")
            else:
                print("Room occupied. Please choose another room.")
        else:
            print("Sorry! Hotel is Full.")

    def searchcust(self):
        id = int(input("Enter booking id of customer: "))
        found_customers = [customer for customer in self.c[:self.ncust] if customer.booking_id == id]

        if found_customers:
            print("\t\t\t Name" + "\t" * 8 + "Phone" + "\t" * 8 + "Address" + "\t" * 8 + "Room no:" + "\t" * 7)
            for customer in found_customers:
                customer.display()
        else:
            print("No customer found.")

    def CheckOut(self):
        rno = int(input("Enter room number: "))
        room_index = next((i for i, room in enumerate(self.a[:self.nroom]) if room.roomNumber == rno), None)

        if room_index is not None and self.a[room_index].status == 1:
            for i in range(self.ncust):
                if self.c[i].room == rno:
                    print("CHECKING OUT.")
                    self.c[i].display()
                    print(f"Your total bill is {self.c[i].bill:.2f}")
                    print(f"Adv payment: {self.c[i].payment_advance:.2f}")
                    print(f"Hence, pending payment = Rs. {self.c[i].bill - self.c[i].payment_advance:.2f}")
                    print("Thank you! Visit Again :)")
                    self.a[room_index].status = 0
                    self.c[i].status = 0
                    break
        else:
            print("Invalid room number or room is not occupied.")

    def Summary(self):
        if self.nroom == 0:
            print("No customers as yet.")
            return

        print("Guest Summary:")
        print("Id.\t\t| Name" + "\t" * 10 + "| Phone" + "\t" * 7 + "| Address" + "\t" * 8 + "| Room no:\t| Status\t\t|")
        for i in range(self.ncust):
            self.c[i].display()

if __name__ == "__main__":
    Taj = Hotel()

    print("======================================================================================WELCOME TO DESTINY GROUP OF HOTELS========================================================================================")
    while True:
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
        print("\t\t\t\t\t\t\t\t\t\t\tMENU:\n\t\t\t\t\t\t\t\t\t\t\t1.OPERATE AS ADMIN\n\t\t\t\t\t\t\t\t\t\t\t2.OPERATE AS CUSTOMER\n\t\t\t\t\t\t\t\t\t\t\t3.EXIT")
        ch = input("Enter your choice: ")

        if ch == '1':
            print("Add database of rooms in the hotel:")
            Taj.addRooms()
            print("Database updated. Going back to main menu.")
        elif ch == '2':
            while True:
                print("*************************************************************************************************************************************************************************************************")
                print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~WELCOME TO DESTINY GROUP OF HOTELS~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
                print("\n\t\t\t\t\t\t\t\t\t\t\tMenu:\n\t\t\t\t\t\t\t\t\t\t\t1.Check Availability of rooms.\n\t\t\t\t\t\t\t\t\t\t\t2.Search Room\n\t\t\t\t\t\t\t\t\t\t\t3.Check In\n\t\t\t\t\t\t\t\t\t\t\t4.Search Customer\n\t\t\t\t\t\t\t\t\t\t\t5.Guest Summary\n\t\t\t\t\t\t\t\t\t\t\t6.Checkout.\n\t\t\t\t\t\t\t\t\t\t\t7.Go back to Main Menu.")
                ch1 = input("Enter your choice: ")

                if ch1 == '1':
                    Taj.availability()
                elif ch1 == '2':
                    Taj.searchroom()
                elif ch1 == '3':
                    Taj.CheckIn()
                elif ch1 == '4':
                    Taj.searchcust()
                elif ch1 == '5':
                    Taj.Summary()
                elif ch1 == '6':
                    Taj.CheckOut()
                elif ch1 == '7':
                    break
                else:
                    print("Invalid Choice.")
        elif ch == '3':
            print("Thank you!")
            break
        else:
            print("Invalid Choice.")
